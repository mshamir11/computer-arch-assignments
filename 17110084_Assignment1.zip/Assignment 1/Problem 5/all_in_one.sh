gcc 1_recursion.c -o 1_recursion && ./1_recursion
gcc 2_loop.c -o 2_loop && ./2_loop
gcc 3_recursion_memoization.c -o 3_recursion_memoization && ./3_recursion_memoization
gcc 4_loop_memoization.c -o 4_loop_memoization && ./4_loop_memoization
